/********************************************************************
 * 
 * 
 * 
 * 
 * 
 * 
 * ******************************************************************/

#include "SettingsPage.hpp"

namespace
{
    sf::Text titleText, changeFontText;
    sf::Texture texture;
    sf::Sprite sprite;
    Button arial, roboto, futura, times, homePageButton;
    sf::Font arialF, robotoF, futuraF, timesF;
}

// Create all the components for the page
void SettingsPage::createPage()
{
    /**** Title Text ****/ 
    titleText.setString("Settings");
    titleText.setFont(font);
    titleText.setCharacterSize(60);
    titleText.setFillColor(sf::Color::White);
    titleText.setPosition(400 - titleText.getLocalBounds().width / 2, 50);

    /**** Change Font Text ****/ 
    changeFontText.setString("Change Font:");
    changeFontText.setFont(font);
    changeFontText.setCharacterSize(40);
    changeFontText.setFillColor(sf::Color(123, 187, 249, 250));
    changeFontText.setPosition(75, 250);

    /**** Title Bar ****/
    if (!texture.loadFromFile("./Images/Gather Setting Banner.png", sf::IntRect(0, 160, 800, 190)))
    {
        std::cout << "\nTitle Bar image could not be loaded from the file.\n";
    }
    texture.setSmooth(true);
    sprite.setTexture(texture);

    /*** Button for the Arial Font ***/
    arial.setButtonColor(sf::Color(123, 187, 249, 250));
    arial.setTextColor(sf::Color::White);
    arial.setText("Arial");
    arial.setTextSize(40);
    arial.setSize({ 400, 75 });
    arial.setPosition({ 200, 350 });
    if (!arialF.loadFromFile("arial.ttf"))
    {
        std::cout << "\nArial font could not be loaded from the file.\n";
    }
    arial.setFont(arialF);

    /*** Button for the Roboto Font ***/
    roboto.setButtonColor(sf::Color(123, 187, 249, 250));
    roboto.setTextColor(sf::Color::White);
    roboto.setText("Roboto");
    roboto.setTextSize(40);
    roboto.setSize({ 400, 75 });
    roboto.setPosition({ 200, 450 });
    if (!robotoF.loadFromFile("Roboto-Black.ttf"))
    {
        std::cout << "\nRoboto font could not be loaded from the file.\n";
    }
    roboto.setFont(robotoF);

    /*** Button for the Futura Font ***/
    futura.setButtonColor(sf::Color(123, 187, 249, 250));
    futura.setTextColor(sf::Color::White);
    futura.setText("Futura");
    futura.setTextSize(40);
    futura.setSize({ 400, 75 });
    futura.setPosition({ 200, 550 });
    if (!futuraF.loadFromFile("Futura.ttc"))
    {
        std::cout << "\nFutura font could not be loaded from the file.\n";
    }
    futura.setFont(futuraF);

    /*** Button for the Times Font ***/
    times.setButtonColor(sf::Color(123, 187, 249, 250));
    times.setTextColor(sf::Color::White);
    times.setText("Times");
    times.setTextSize(40);
    times.setSize({ 400, 75 });
    times.setPosition({ 200, 650 });
    if (!timesF.loadFromFile("Times.ttc"))
    {
        std::cout << "\nTimes font could not be loaded from the file.\n";
    }
    times.setFont(timesF);

    /**** Home Button ****/ 
    homePageButton.setButtonColor(sf::Color::Transparent);
    homePageButton.setText("");
    homePageButton.setSize({ 100, 100 });
    homePageButton.setPosition({ 670, 45 });
}

// Draw the page to the window
void SettingsPage::drawPage()
{
    arial.setPosition({ 200, 350 });
    roboto.setPosition({200, 450});
    futura.setPosition({200, 550});
    times.setPosition({200, 650});

    window->draw(sprite);
    window->draw(titleText);
    arial.drawTo(*window);
    roboto.drawTo(*window);
    futura.drawTo(*window);
    times.drawTo(*window);
    homePageButton.drawTo(*window);
    window->draw(changeFontText);
}

// Perform the event operations
void SettingsPage::eventOperation(const sf::Event & event)
{
    // change color of the buttons when mouse hovers over it
    if (event.type == sf::Event::MouseMoved)
    {
        if (arial.mouseHover(*window))
            arial.setButtonColor(sf::Color(160, 197, 250, 200));    //changes color
        else 
            arial.setButtonColor(sf::Color(123, 187, 249, 250));      // keep the color the same

        if (roboto.mouseHover(*window))
            roboto.setButtonColor(sf::Color(160, 197, 250, 200));    //changes color
        else 
            roboto.setButtonColor(sf::Color(123, 187, 249, 250));      // keep the color the same

        if (futura.mouseHover(*window))
            futura.setButtonColor(sf::Color(160, 197, 250, 200));    //changes color
        else 
            futura.setButtonColor(sf::Color(123, 187, 249, 250));      // keep the color the same

        if (times.mouseHover(*window))
            times.setButtonColor(sf::Color(160, 197, 250, 200));    //changes color
        else 
            times.setButtonColor(sf::Color(123, 187, 249, 250));      // keep the color the same
    }

    // If a button was pressed, perform the operation tied to the button
    if (event.type == sf::Event::MouseButtonPressed)
    {
        if (homePageButton.mouseHover(*window))        
        {
            changePage = true;
            newPage = Page::CurrentPage::HomePage;
        }
        if (arial.mouseHover(*window))
        {
            this->fontChange = "Arial";
            changeF = true;
            font = arialF;
        }   
        if (roboto.mouseHover(*window))
        {
            this->fontChange = "Roboto";
            changeF = true;
            font = robotoF;
        }
        if (futura.mouseHover(*window))
        {
            this->fontChange = "Futura";
            changeF = true;
            font = futuraF;
        }
        if (times.mouseHover(*window))
        {
            this->fontChange = "Times";
            changeF = true;
            font = timesF;
        }
    }
}