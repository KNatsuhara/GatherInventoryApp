/********************************************************************
 * 
 * 
 * 
 * 
 * 
 * 
 * ******************************************************************/

// Libraries
#include <SFML/Graphics.hpp>
#include <time.h>

// Page classes
#include "Page.hpp"
#include "HomePage.hpp"
#include "SettingsPage.hpp"
#include "ItemPage.hpp"
#include "InventoryPage.hpp"
#include "AboutPage.hpp"
#include "UserPage.hpp"

int main(void)
{
    /**** Time ****/
    srand(time(NULL));

    /**** Window ****/ 
    sf::RenderWindow window(sf::VideoMode(800, 1000), "Name");
    window.setFramerateLimit(60);
	window.setKeyRepeatEnabled(true);

    /**** Set Font ****/
	sf::Font font;
    // load desired font from project folder
	font.loadFromFile("arial.ttf");

    /**** Alternative Fonts ****/
    sf::Font arial, roboto, futura, times;
    arial.loadFromFile("arial.ttf");
    roboto.loadFromFile("Roboto-Black.ttf");
    futura.loadFromFile("Futura.ttc");
    times.loadFromFile("Times.ttc");

    /***** Background ****/ 
	sf::RectangleShape background;
	background.setSize(sf::Vector2f(800, 1400));
    background.setFillColor(sf::Color::White);
	background.setPosition(0, 0);

    /***** Create Homepage *****/ 
    Page * nPage = new HomePage;             // Application starts with the homepage
    nPage->setFont(font);
    nPage->setWindow(window);
    nPage->createPage();                     // create page components

    /***** Application Loop *****/
    while (window.isOpen())
    {
        sf::Event event;

        while (window.pollEvent(event))
        {
            switch (event.type)
			{
			case sf::Event::Closed:				 
				window.close();              // close window
				break;
            default:
                break;
            };

            nPage->eventOperation(event);    // Perform operations
        }

        window.clear();                      // Draw the window and current page
        window.draw(background);
        nPage->drawPage();
        window.display();

        if (nPage->getChangeFont() == true)
        {
            std::string s = nPage->getNewFont();

            if (s == "Roboto")
                font = roboto;
            else if (s == "Futura")
                font = futura;
            else if (s == "Times")
                font = times;
            else if (s == "Arial")
                font = arial;
            else 
            {   }
            
            nPage->setChangeFontBool(false);
        }

        if (nPage->getChange())             // If the page was changed / button pressed
        {
            Page::CurrentPage change = nPage->getPage();
            

            if (change == Page::CurrentPage::HomePage)   // change to the homepage
            {
                nPage = new HomePage;
                nPage->setFont(font);
                nPage->setWindow(window);
                nPage->createPage();                     // create page components
                nPage->setChange(false);
            }
            else if (change == Page::CurrentPage::SettingsPage)     // change to the settings page
            {
                nPage = new SettingsPage;
                nPage->setFont(font);
                nPage->setWindow(window);
                nPage->createPage();                     // create page components
                nPage->setChange(false);
            }
            else if (change == Page::CurrentPage::ItemPage) //change to the item page
            {
                nPage = new ItemPage;
                nPage->setFont(font);
                nPage->setWindow(window);
                nPage->createPage();                     // create page components
                nPage->setChange(false);
            }
            else if (change == Page::CurrentPage::InventoryPage) //change to the item page
            {
                nPage = new InventoryPage;
                nPage->setFont(font);
                nPage->setWindow(window);
                nPage->createPage();                     // create page components
                nPage->setChange(false);
            }
            else if (change == Page::CurrentPage::AboutPage) //change to the about page
            {
                nPage = new AboutPage;
                nPage->setFont(font);
                nPage->setWindow(window);
                nPage->createPage();                     // create page components
                nPage->setChange(false);
            }
            else if (change == Page::CurrentPage::UserPage) //change to the User page
            {
                nPage = new UserPage;
                nPage->setFont(font);
                nPage->setWindow(window);
                nPage->createPage();                     // create page components
                nPage->setChange(false);
            }
            else {      }   
        }
    }
    // end loop

    return 0;
}