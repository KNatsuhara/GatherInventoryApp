/********************************************************************
 * 
 * 
 * 
 * 
 * 
 * 
 * ******************************************************************/

#ifndef PAGE_HPP
#define PAGE_HPP

#include <SFML/Graphics.hpp>

// Parent class for all pages
class Page
{
public:

    // variables for identifying the current page
    enum class CurrentPage
    {
        HomePage, SettingsPage, ItemPage, InventoryPage, AboutPage, UserPage
    };

    // Default Constructor
    Page();

    // Destructor
    ~Page();
    
    // Setters
    void setFont (const sf::Font &f);
    void setWindow (sf::RenderWindow &w);
    void setChange(const bool &change);
    void setChangeFontBool(const bool &change);

    // Getters
    bool getChange(void);
    CurrentPage getPage(void) { return newPage; }
    bool getChangeFont(void);
    std::string getNewFont(void);

    // Change the font
    void changeFont (const sf::Font f);

    /****  Virtual Functions to be implemented by page classes  ****/

    // Create all the components for the page
    virtual void createPage() = 0;

    // Draw the page to the window
    virtual void drawPage() = 0;

    // Perform the event operations
    virtual void eventOperation(const sf::Event & event) = 0;

protected:
    bool changePage;                // determines if the page was changed
    CurrentPage newPage;            // the new page to change to 
    sf::Font font;                  // font
    sf::RenderWindow * window;      // current window

    std::string fontChange;            // change font
    bool changeF;

};

#endif