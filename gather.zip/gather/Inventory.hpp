#ifndef INVENTORY_HPP
#define INVENTORY_HPP 

#include "Item.hpp" 
#include <map>
#include <string>
#include <fstream> 
#include <iostream> 

/*
Contains map for storing <string,Item>
Does not store duplicates, but will not throw an error when given a duplicate.
*/
class Inventory
{
private:
	std::map<std::string,Item> inv;
public:
	//Default constructor
	Inventory(bool openFile=true, std::string fileName="inventoryData.csv");
	~Inventory();
	//Insert individual member values
	void insert(std::string name, std::string category, std::string exp, double price, int quantity);
	//Insert Item object
	void insert(Item x);
	//Legacy find 
	Item* find(std::string name);
	//Check if map contains an item with a given key
	bool contains(std::string name);
	/*
	Search map for keys that start with a given string.
	Returns pointer to an array of 8 Items.
	If fewer than 8 matches found, array is populated with empty Items.
	*/
	Item* search(std::string name);
	void remove(std::string name);
	void updateName(std::string name, std::string n);
	void updateCategory(std::string name, std::string cat);
	void updateExpiration(std::string name, std::string exp);
	void updatePrice(std::string name, double p);
	//Update quantity for an item.
	//Throws std::out_of_range if not found
	void updateQuantity(std::string name, int q);
	//Edit any one value for an item.
	//Assumes item exists in map. Throws std::out_of_range if not found.
	void updateItem(std::string name, int operation, std::string data);
	//Legacy function. Allow user to choose an item to edit. Text-based.
	void updateItem();
	//Print entire map to the given stream, default is std::cout
	void printAlphabetical(std::ostream& out = std::cout);
	//Read inventory data from a CSV file
	bool readCSV(std::string filename);
	void writeCSV(std::string filename);
	Item* getKItems(int k);
	int getSize();
};

#endif //INVENTORY_HPP
