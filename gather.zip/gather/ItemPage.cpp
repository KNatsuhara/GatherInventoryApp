/********************************************************************
 * 
 * 
 * 
 * 
 * 
 * 
 * ******************************************************************/

#include "ItemPage.hpp"
#include "Inventory.hpp"

// Page Components 
namespace
{
    sf::Text titleText, itemName, itemDate, itemQuantity, itemCategory, itemPrice, dateFormat, priceFormat, added, updated, removed;
    bool addCase, updateCase, removeCase;
    sf::Sprite sprite;
    sf::Texture texture;
    Button b, update, del, settings, home;
	TextBox textboxName(30, sf::Color::Black, false, {400, 75}), textboxDate(30, sf::Color::Black, false, {400, 75}), textboxQuantity(30, sf::Color::Black, false, {400, 75}),
        textboxCategory(30, sf::Color::Black, false, {400, 75}), textboxPrice(30, sf::Color::Black, false, {400, 75});
    int i = 0, z = 0;
    int quan = 0;
    double cost = 0;
    Item item("Name", "Category", "MM/DD/YYYY", 0, 0);
    std::string tempName, tempCat, tempDate;
}

/**********************************************************
*  Create all the components for the page.                *
***********************************************************/
void ItemPage::createPage()
{
    /**** Title text ****/
    titleText.setString("  Items");
    titleText.setFont(font);
    titleText.setCharacterSize(60);
    titleText.setFillColor(sf::Color::White);
    titleText.setPosition(265, 50);

    /**** Title Bar ****/
    if (!texture.loadFromFile("./Images/Gather Pinkblue Banner.png", sf::IntRect(0, 160, 800, 190)))
    {
        std::cout << "\nTitle Bar image could not be loaded from the file.\n";
    }
    texture.setSmooth(true);
    sprite.setTexture(texture);

    /**** Item Name text ****/
    itemName.setString("Item Name:");
    itemName.setFont(font);
    itemName.setCharacterSize(25);
    itemName.setFillColor(sf::Color::Black);
    itemName.setPosition(65, 310);

    /**** Textbox Item Name****/
	textboxName.setFont(font);
	textboxName.setPosition({ 220, 300 });
	textboxName.setLimit(true, 20);
    textboxName.setTextToBox(ultItem.getItemName());

    /**** Category Name text ****/
    itemCategory.setString("Category:");
    itemCategory.setFont(font);
    itemCategory.setCharacterSize(25);
    itemCategory.setFillColor(sf::Color::Black);
    itemCategory.setPosition(65, 410);

    /**** Textbox Category Name ****/
	textboxCategory.setFont(font);
	textboxCategory.setPosition({ 220, 400 });
	textboxCategory.setLimit(true, 20);
    textboxCategory.setTextToBox(ultItem.getCategory());

    /**** Expiration Date text ****/
    itemDate.setString("Expiration:");
    itemDate.setFont(font);
    itemDate.setCharacterSize(25);
    itemDate.setFillColor(sf::Color::Black);
    itemDate.setPosition(65, 510);

    /**** Textbox Expiration Date ****/
	textboxDate.setFont(font);
	textboxDate.setPosition({ 220, 500 });
	textboxDate.setLimit(true, 20);
    textboxDate.setTextToBox(ultItem.getExpirationDate());

    /**** Textbox Format Date ****/
    dateFormat.setString("Format: MM/DD/YYYY");
    dateFormat.setFont(font);
    dateFormat.setCharacterSize(15);
    dateFormat.setFillColor(sf::Color::Black);
    dateFormat.setPosition(615, 510);

    /**** Quantity text ****/
    itemQuantity.setString("Quantity:");
    itemQuantity.setFont(font);
    itemQuantity.setCharacterSize(25);
    itemQuantity.setFillColor(sf::Color::Black);
    itemQuantity.setPosition(65, 610);

    /**** Textbox Quantity ****/
	textboxQuantity.setFont(font);
	textboxQuantity.setPosition({ 220, 600 });
	textboxQuantity.setLimit(true, 20);
    textboxQuantity.setTextToBox(std::to_string(ultItem.getQuantity()));

    /**** Price text ****/
    itemPrice.setString("Price:      $");
    itemPrice.setFont(font);
    itemPrice.setCharacterSize(25);
    itemPrice.setFillColor(sf::Color::Black);
    itemPrice.setPosition(65, 710);

    /**** Textbox Price ****/
	textboxPrice.setFont(font);
	textboxPrice.setPosition({ 220, 700 });
	textboxPrice.setLimit(true, 20);

    std::string price = std::to_string(ultItem.getPrice());
    std::string newPrice = "";
    z = 0;
    while (price[z] != '.')
    {
        newPrice = newPrice + price[z];
        ++z;
    }
    newPrice = newPrice + price[z] + price[z+1] + price[z+2];

    textboxPrice.setTextToBox(newPrice);

    /**** Button *****/
    b.setButtonColor(sf::Color(119, 51, 255, 250));
    b.setTextColor(sf::Color::White);
    b.setText("Add");
    b.setTextSize(35);
    b.setSize({ 200, 75 });
    b.setPosition({ 325, 800 });
    b.setFont(font);

    update.setButtonColor(sf::Color(119, 51, 255, 250));
    update.setTextColor(sf::Color::White);
    update.setText("Update");
    update.setTextSize(35);
    update.setSize({ 200, 75 });
    update.setPosition({ 100, 800 });
    update.setFont(font);

    del.setButtonColor(sf::Color(119, 51, 255, 250));
    del.setTextColor(sf::Color::White);
    del.setText("Remove");
    del.setTextSize(35);
    del.setSize({ 200, 75 });
    del.setPosition({ 550, 800 });
    del.setFont(font);

    /**** Home Button ****/ 
    home.setButtonColor(sf::Color::Transparent);
    home.setText("");
    home.setSize({ 100, 100 });
    home.setPosition({ 670, 50 });

    /**** Settings Button ****/ 
    settings.setButtonColor(sf::Color::Transparent);
    settings.setText("");
    settings.setSize({ 100, 100 });
    settings.setPosition({ 30, 50 });

    /**** Item Name text ****/
    added.setString("Item Added!");
    added.setFont(font);
    added.setCharacterSize(25);
    added.setFillColor(sf::Color::Magenta);
    added.setPosition(325, 900);

    /**** Item Name text ****/
    updated.setString("Item Updated!");
    updated.setFont(font);
    updated.setCharacterSize(25);
    updated.setFillColor(sf::Color::Magenta);
    updated.setPosition(325, 900);

    /**** Item Name text ****/
    removed.setString("Item Removed!");
    removed.setFont(font);
    removed.setCharacterSize(25);
    removed.setFillColor(sf::Color::Magenta);
    removed.setPosition(325, 900);
}

/**********************************************************
*  Draw the page to the window.                           *
***********************************************************/
void ItemPage::drawPage(void)
{
    /**** Draw ****/
    b.setPosition({ 325, 800 });
    update.setPosition({ 100, 800 });
    del.setPosition({ 550, 800 });
    window->draw(sprite);
    window->draw(titleText);
    window->draw(itemName);
    window->draw(itemCategory);
    window->draw(itemDate);
    window->draw(itemPrice);
    window->draw(itemQuantity);
    window->draw(dateFormat);
    textboxDate.drawTo(*window);
    textboxPrice.drawTo(*window);
    textboxQuantity.drawTo(*window);
    textboxCategory.drawTo(*window);
    textboxName.drawTo(*window);
    b.drawTo(*window);
    update.drawTo(*window);
    del.drawTo(*window);
    settings.drawTo(*window);
    if(addCase)
        window->draw(added);
    if(updateCase)
        window->draw(updated);
    if(removeCase)
        window->draw(removed);
    i++;
    if(i == 60)
    {
        addCase = false;
        updateCase = false;
        removeCase = false;
        i = 0;
    }
} 

/**********************************************************
*  Perform the event operations.                          *
***********************************************************/
void ItemPage::eventOperation(const sf::Event & event, Inventory &inventory, Item &item)
{
    // change color of the buttons when mouse hovers over it
    if (event.type == sf::Event::MouseMoved)
    {
        if (b.mouseHover(*window))
        {
            b.setButtonColor(sf::Color(155, 155, 206, 255));    //changes color
        }
        else 
        {
            b.setButtonColor(sf::Color(119, 51, 255, 250));      // keep the color the same
        }
    }

    // If a button was pressed, perform the operation tied to the button
    if (event.type == sf::Event::MouseButtonPressed)
    {
        if (b.mouseHover(*window))           // if the add button is pressed, change to about add
        {
            i = 0;
            addCase = true;
            if(textboxPrice.getText() == "")
                cost = 0;
            else
                cost = std::stod(textboxPrice.getText());
            if(textboxQuantity.getText() == "")
                quan = 0;
            else
                quan = std::stoi(textboxQuantity.getText());
            
            inventory.insert(textboxName.getText(), textboxCategory.getText(), textboxDate.getText(), cost, quan);
            //void insert(std::string name, std::string category, std::string exp, double price, int quantity);
        }
    }

    // change color of the buttons when mouse hovers over it
    if (event.type == sf::Event::MouseMoved)
    {
        if (update.mouseHover(*window))
        {
            update.setButtonColor(sf::Color(155, 155, 206, 255));    //changes color
        }
        else 
        {
            update.setButtonColor(sf::Color(119, 51, 255, 250));      // keep the color the same
        }
    }

    // If a button was pressed, perform the operation tied to the button
    if (event.type == sf::Event::MouseButtonPressed)
    {
        if (update.mouseHover(*window))           // if the add button is pressed, change to about add
        {
            i = 0;
            updateCase = true;
            if(textboxPrice.getText() == "")
                cost = ultItem.getPrice();
            else
                cost = std::stod(textboxPrice.getText());
            if(textboxQuantity.getText() == "")
                quan = ultItem.getQuantity();
            else
            {
                quan = std::stoi(textboxQuantity.getText());
            }
            if(textboxName.getText() == "")
                tempName = ultItem.getItemName();
            else
            {
                tempName = textboxName.getText();
            }
            if(textboxCategory.getText() == "")
                tempCat = ultItem.getCategory();
            else
            {
                tempCat = textboxCategory.getText();
            }
            if(textboxDate.getText() == "")
                tempDate = ultItem.getExpirationDate();
            else
            {
                tempDate = textboxDate.getText();
            }

	        inventory.updateName(ultItem.getItemName(), tempName);
	        inventory.updateCategory(ultItem.getItemName(), tempCat);
	        inventory.updateExpiration(ultItem.getItemName(), tempDate);
	        inventory.updatePrice(ultItem.getItemName(), cost);
	        inventory.updateQuantity(ultItem.getItemName(), quan);
        }
    }

    // change color of the buttons when mouse hovers over it
    if (event.type == sf::Event::MouseMoved)
    {
        if (del.mouseHover(*window))
        {
            del.setButtonColor(sf::Color(155, 155, 206, 255));    //changes color
        }
        else 
        {
            del.setButtonColor(sf::Color(119, 51, 255, 250));      // keep the color the same
        }
    }

    // If a button was pressed, perform the operation tied to the button
    if (event.type == sf::Event::MouseButtonPressed)
    {
        if (del.mouseHover(*window))           // if the add button is pressed, change to about add
        {
            i = 0;
            removeCase = true;
            if(textboxName.getText() == "")
                tempName = ultItem.getItemName();
            else
            {
                tempName = textboxName.getText();
            }
            inventory.remove(tempName);
        }
    }

    // If a button was pressed, perform the operation tied to the button
    if (event.type == sf::Event::MouseButtonPressed)
    {
        if (settings.mouseHover(*window))           // if the settings button is pressed, change to settings page
        {
            changePage = true;
            newPage = Page::CurrentPage::SettingsPage;
        }
    }

    //Homepage Button event operation
    if (event.type == sf::Event::MouseButtonPressed)
    {
        if (home.mouseHover(*window))           // if the home button is pressed, change to home page
        {
            changePage = true;
            newPage = Page::CurrentPage::HomePage;
        }
    }
    
    // for selecting the textbox
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Return))
	{
		textboxName.setSelected(true);
	}
	else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Escape))
	{
		textboxName.setSelected(false);
	}

    // for typing into the textbox
    if (event.type == sf::Event::TextEntered)
    {
		textboxName.type(event);
    }

    if (event.type == sf::Event::MouseButtonReleased)
    {
        if (event.mouseButton.button == sf::Mouse::Left)
        {
            if (textboxName.mouseHover(*window))
            {
                textboxName.setSelected(true);
                textboxName.setOutlineColor(sf::Color::Black);
            }
            else
            {
                textboxName.setSelected(false);
                textboxName.setOutlineColor(sf::Color(192, 192, 192, 250));
            }
        }
    }

    // for selecting the textbox
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Return))
	{
		textboxCategory.setSelected(true);
	}
	else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Escape))
	{
		textboxCategory.setSelected(false);
	}

    // for typing into the textbox
    if (event.type == sf::Event::TextEntered)
    {
		textboxCategory.type(event);
    }

    if (event.type == sf::Event::MouseButtonReleased)
    {
        if (event.mouseButton.button == sf::Mouse::Left)
        {
            if (textboxCategory.mouseHover(*window))
            {
                textboxCategory.setSelected(true);
                textboxCategory.setOutlineColor(sf::Color::Black);
            }
            else
            {
                textboxCategory.setSelected(false);
                textboxCategory.setOutlineColor(sf::Color(192, 192, 192, 250));
            }
        }
    }

    // for selecting the textbox
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Return))
	{
		textboxDate.setSelected(true);
	}
	else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Escape))
	{
		textboxDate.setSelected(false);
	}

    // for typing into the textbox
    if (event.type == sf::Event::TextEntered)
    {
		textboxDate.type(event);
    }

    if (event.type == sf::Event::MouseButtonReleased)
    {
        if (event.mouseButton.button == sf::Mouse::Left)
        {
            if (textboxDate.mouseHover(*window))
            {
                textboxDate.setSelected(true);
                textboxDate.setOutlineColor(sf::Color::Black);
            }
            else
            {
                textboxDate.setSelected(false);
                textboxDate.setOutlineColor(sf::Color(192, 192, 192, 250));
            }
        }
    }

    // for selecting the textbox
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Return))
	{
		textboxPrice.setSelected(true);
	}
	else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Escape))
	{
		textboxPrice.setSelected(false);
	}

    // for typing into the textbox
    if (event.type == sf::Event::TextEntered)
    {
		textboxPrice.type(event);
    }

    if (event.type == sf::Event::MouseButtonReleased)
    {
        if (event.mouseButton.button == sf::Mouse::Left)
        {
            if (textboxPrice.mouseHover(*window))
            {
                textboxPrice.setSelected(true);
                textboxPrice.setOutlineColor(sf::Color::Black);
            }
            else
            {
                textboxPrice.setSelected(false);
                textboxPrice.setOutlineColor(sf::Color(192, 192, 192, 250));
            }
        }
    }

    // for selecting the textbox
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Return))
	{
		textboxQuantity.setSelected(true);
	}
	else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Escape))
	{
		textboxQuantity.setSelected(false);
	}

    // for typing into the textbox
    if (event.type == sf::Event::TextEntered)
    {
		textboxQuantity.type(event);
    }

    if (event.type == sf::Event::MouseButtonReleased)
    {
        if (event.mouseButton.button == sf::Mouse::Left)
        {
            if (textboxQuantity.mouseHover(*window))
            {
                textboxQuantity.setSelected(true);
                textboxQuantity.setOutlineColor(sf::Color::Black);
            }
            else
            {
                textboxQuantity.setSelected(false);
                textboxQuantity.setOutlineColor(sf::Color(192, 192, 192, 250));
            }
        }
    }
} 