/********************************************************************
 * 
 * 
 * 
 * 
 * 
 * 
 * ******************************************************************/

#ifndef ITEMPAGE_HPP
#define ITEMPAGE_HPP

#include "Page.hpp"

#include "Button.hpp"
#include "TextBox.hpp"

#include <SFML/Graphics.hpp>

// Class for the HomePage of the app -> first page when the app opens
class ItemPage : public Page
{
public:
    // Default Constructor
    ItemPage() : Page() {   }

    // Create all the components for the page
    virtual void createPage();

    // Draw the page to the window
    virtual void drawPage();

    // Perform the event operations
    virtual void eventOperation(const sf::Event & event);
    
};

#endif