/********************************************************************
 * 
 * 
 * 
 * 
 * 
 * 
 * ******************************************************************/

#include "HomePage.hpp"

// Page Components 
namespace
{
    sf::Text titleText;
    sf::Sprite sprite;
    sf::Texture texture;
    Button items, inventory, about, quit, settings, home, user;
}

/**********************************************************
*  Create all the components for the page.                *
***********************************************************/
void HomePage::createPage()
{
    /**** Title text ****/
    titleText.setString("Gather");
    titleText.setFont(font);
    titleText.setCharacterSize(60);
    titleText.setFillColor(sf::Color::White);
    titleText.setPosition(400 - titleText.getLocalBounds().width / 2, 50);

    /**** Title Bar ****/
    if (!texture.loadFromFile("./Images/Gather Homepage Banner1.png", sf::IntRect(0, 160, 800, 190)))
    {
        std::cout << "\nTitle Bar image could not be loaded from the file.\n";
    }
    texture.setSmooth(true);
    sprite.setTexture(texture);

    /**** Items Button*****/
    items.setButtonColor(sf::Color(129, 180, 182, 255)); //159, 226, 228, 255
    items.setTextColor(sf::Color::White);
    items.setText("Items");
    items.setTextSize(40);
    items.setSize({ 400, 75 });
    items.setPosition({ 200, 300 });
    items.setFont(font);

    /**** Inventory Button *****/
    inventory.setButtonColor(sf::Color(129, 180, 182, 255));
    inventory.setTextColor(sf::Color::White);
    inventory.setText("Inventory");
    inventory.setTextSize(40);
    inventory.setSize({ 400, 75 });
    inventory.setPosition({ 200, 400 });
    inventory.setFont(font);

    /**** Inventory Button *****/
    user.setButtonColor(sf::Color(129, 180, 182, 255));
    user.setTextColor(sf::Color::White);
    user.setText("List");
    user.setTextSize(40);
    user.setSize({ 400, 75 });
    user.setPosition({ 200, 500 });
    user.setFont(font);

    /**** About Button *****/
    about.setButtonColor(sf::Color(129, 180, 182, 255));
    about.setTextColor(sf::Color::White);
    about.setText("About");
    about.setTextSize(40);
    about.setSize({ 400, 75 });
    about.setPosition({ 200, 600 });
    about.setFont(font);

    /**** Exit Button *****/
    quit.setButtonColor(sf::Color(129, 180, 182, 255));
    quit.setTextColor(sf::Color::White);
    quit.setText("Exit");
    quit.setTextSize(40);
    quit.setSize({ 400, 75 });
    quit.setPosition({ 200, 700 });
    quit.setFont(font);

    /**** Home Button ****/ 
    home.setButtonColor(sf::Color::Transparent);
    home.setText("");
    home.setSize({ 100, 100 });
    home.setPosition({ 670, 50 });

    /**** Settings Button ****/ 
    settings.setButtonColor(sf::Color::Transparent);
    settings.setText("");
    settings.setSize({ 100, 100 });
    settings.setPosition({ 30, 50 });

}

/**********************************************************
*  Draw the page to the window.                           *
***********************************************************/
void HomePage::drawPage(void)
{
    items.setPosition({200, 300});
    inventory.setPosition({ 200, 400 });
    user.setPosition({ 200, 500 });
    about.setPosition({ 200, 600 });
    quit.setPosition({ 200, 700 });

    /**** Draw ****/
    window->draw(sprite);           // Title Bar
    window->draw(titleText);        // Title Text
    items.drawTo(*window);          // Items button
    settings.drawTo(*window);       // Settings button
    inventory.drawTo(*window);      // Inventory button
    user.drawTo(*window);           // User button
    about.drawTo(*window);          // About button
    quit.drawTo(*window);           // Exit button
} 

/**********************************************************
*  Perform the event operations.                          *
***********************************************************/
void HomePage::eventOperation(const sf::Event & event)
{
    // Change color of the buttons when mouse hovers over it
    if (event.type == sf::Event::MouseMoved)
    {
        if (user.mouseHover(*window))
            user.setButtonColor(sf::Color(186, 239, 129, 150));    //changes color of user button
        else 
            user.setButtonColor(sf::Color(129, 180, 182, 255));    // keep the color the same
        
        if (about.mouseHover(*window))
            about.setButtonColor(sf::Color(186, 239, 129, 150));   // changes color of about button
        else 
            about.setButtonColor(sf::Color(129, 180, 182, 255));   // keep the color the same

        if (inventory.mouseHover(*window))
            inventory.setButtonColor(sf::Color(186, 239, 129, 150));    //changes color of inventory button
        else 
            inventory.setButtonColor(sf::Color(129, 180, 182, 255));    // keep the color the same

        if (quit.mouseHover(*window))
            quit.setButtonColor(sf::Color(186, 239, 129, 150));    //changes color of inventory button
        else 
            quit.setButtonColor(sf::Color(129, 180, 182, 255));    // keep the color the same

        if (items.mouseHover(*window))
            items.setButtonColor(sf::Color(186, 239, 129, 150));    //changes color of inventory button
        else 
            items.setButtonColor(sf::Color(129, 180, 182, 255));    // keep the color the same
    }

    // If a button was pressed, perform the operation tied to the button
    if (event.type == sf::Event::MouseButtonPressed)
    {
        if (settings.mouseHover(*window))       // if the settings button is pressed, change to settings page
        {
            changePage = true;
            newPage = Page::CurrentPage::SettingsPage;
        }
        if (home.mouseHover(*window))           // if the home button is pressed, change to home page
        {
            changePage = true;
            newPage = Page::CurrentPage::HomePage;
        }
        if (user.mouseHover(*window))           // if the user button is pressed, change to about user
        {
            changePage = true;
            newPage = Page::CurrentPage::UserPage;
        }
        if (about.mouseHover(*window))           // if the about button is pressed, change to about page
        {
            changePage = true;
            newPage = Page::CurrentPage::AboutPage;
        }
        if (inventory.mouseHover(*window))           // if the item button is pressed, change to items page
        {
            changePage = true;
            newPage = Page::CurrentPage::InventoryPage;
        }
        if (items.mouseHover(*window))           // if the item button is pressed, change to items page
        {
            changePage = true;
            newPage = Page::CurrentPage::ItemPage;
        }
        if (quit.mouseHover(*window))
        {;
            (*window).close();
        }
    }

    // Press Esc to exit the application
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Escape))
	{
		(*window).close();              // close window
	}
} 