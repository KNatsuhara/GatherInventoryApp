/********************************************************************
 * 
 * 
 * 
 * 
 * 
 * 
 * ******************************************************************/

#include "TextBox.hpp"

//Constructor
TextBox::TextBox(const int &size, const sf::Color &color, const bool &selected, const sf::Vector2f &borderSize)
{
    textbox.setCharacterSize(size);		
	textbox.setFillColor(color);
    border.setSize(borderSize);
	isSelected = selected;
	limit = 0;

	textbox.setString("");
}

// Set font 
void TextBox::setFont(const sf::Font& font)
{
	textbox.setFont(font);
}

//Set position of the textbox
void TextBox::setPosition(const sf::Vector2f &pos)
{
	textbox.setPosition(pos);
    this->setOutline({pos.x - 20, pos.y - 10});
}

// set outline position
void TextBox::setOutline(const sf::Vector2f &pos)
{
    border.setPosition(pos);
    border.setOutlineThickness(2.0);
    border.setOutlineColor(sf::Color(192, 192, 192, 250));
}

//set outline color
void TextBox::setOutlineColor(const sf::Color &c)
{
    border.setOutlineColor(c);
}

// Manage the selection status 
void TextBox::setSelected(const bool &sel)
{
	isSelected = sel;
	if (!sel)
	{
		std::string newText = "";
		std::string textStr = text.str();
		if(textbox.getString() == "")
			newText = ""; //set text in box
		else
		{
			newText = "";
			newText = textbox.getString();
		}
		// for (long unsigned int i = 0; i < textStr.length(); i++)
		// {
		// 	newText += textStr[i];
		// }
		textbox.setString(newText);
	}
}

//Set text to box
void TextBox::setTextToBox(const std::string &str)
{
	textbox.setString(str);
}	

// Set the character limit on the textbox
void TextBox::setLimit(const bool &check, const int &l)
{
	hasLimit = check;
	limit = l - 1;
}

// Get the text typed by the user 
std::string TextBox::getText()
{
	return text.str();
}

// Allows for input of characters 
void TextBox::input(const int &c)
{
	if (c != (DELETE) && c != ENTER && c != ESC)
	{
		text << (char) c;
	}
	else if (c == DELETE)
	{
		if (text.str().length() > 0)
		{
			deleteChar();
		}
	}
	textbox.setString(text.str());
}

// Allows for deleted characters to be removed     
void TextBox::deleteChar()
{
	std::string textStr = text.str();
	std::string newText = "";
	for (long unsigned int i = 0; i < textStr.length() - 1; i++)
	{
		newText += textStr[i];
	}
	text.str("");
	text << newText;

	textbox.setString(text.str());
}

// Handle the typing of characters by the user 
void TextBox::type(const sf::Event &input)
{
    if (isSelected)
	{
		int charTyped = input.text.unicode;
		if (charTyped < 128)
		{
			if (hasLimit)
			{
				if (text.str().length() <= limit)
				{
					this->input(charTyped);
				}
				else if (text.str().length() > limit && charTyped == DELETE)
				{
					deleteChar();
				}
			}
			else
		    {
			    this->input(charTyped);
		    }   
	    }
    }
}

// Draw the text box to the window
void TextBox::drawTo(sf::RenderWindow& window)
{
    window.draw(border);
    window.draw(textbox);
}

// Mouse operations ->check if the mouse is over the textbox
bool TextBox::mouseHover(sf::RenderWindow &window)
{
    float mousePosX = sf::Mouse::getPosition(window).x;
	float mousePosY = sf::Mouse::getPosition(window).y;
    bool hover = border.getGlobalBounds().contains(mousePosX, mousePosY);

    return hover;
}