/********************************************************************
 *
 *
 * 
 * 
 * 
 * 
 * 
 * ******************************************************************/

#ifndef BUTTON_HPP
#define BUTTON_HPP

// Libraries 
#include <iostream>
#include <string>
#include <SFML/Graphics.hpp>

// Button Class
class Button
{
private:
    sf::RectangleShape button;          // rectangle for button shape
    sf::Text text;                      // text on the button

public:

    // Default Constructor
    Button();
    
    // Constructor
    Button(const sf::Color &textColor, const sf::Color &buttonColor, const int &sizeOfCharacters, const std::string &text, const sf::Vector2f &buttonSize);

    // Destructor
    ~Button();

    // Setters
    void setFont(const sf::Font &setFont);
    void setButtonColor(const sf::Color &color);
    void setTextColor(const sf::Color &color);
    void setText(const std::string &s);
    void setSize(const sf::Vector2f &size);
    void setTextSize(const int &s);

    // Button Position
    void setPosition(const sf::Vector2f &pos);

    // Draw Button
    void drawTo(sf::RenderWindow &window);

    // Mouse operations
    bool mouseHover(sf::RenderWindow &window);

};

#endif