/********************************************************************
 * 
 * 
 * 
 * 
 * 
 * 
 * ******************************************************************/

#include "SettingsPage.hpp"

namespace
{
    sf::Text titleText;
}

// Create all the components for the page
void SettingsPage::createPage()
{
    /**** Title Text ****/ 
    titleText.setString(" Settings");
    titleText.setFont(font);
    titleText.setCharacterSize(60);
    titleText.setFillColor(sf::Color::Black);
    titleText.setPosition(265, 50);
}

// Draw the page to the window
void SettingsPage::drawPage()
{
    window->draw(titleText);
}

// Perform the event operations
void SettingsPage::eventOperation(const sf::Event & event)
{
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Escape))
    {
        changePage = true;
        newPage = Page::CurrentPage::HomePage;
    }
}