/********************************************************************
 * 
 * 
 * 
 * 
 * 
 *
 * 
 * ******************************************************************/

#include "InventoryPage.hpp"

// Page Components 
namespace
{
    sf::Text titleText;
    sf::Sprite sprite;
    sf::Texture texture;
    Button items, inventory, about, quit, settings, home;
	TextBox textbox(40, sf::Color::Black, false, {400, 75});
    Page::CurrentPage p;
}

/**********************************************************
*  Create all the components for the page.                *
***********************************************************/
void InventoryPage::createPage()
{
    /**** Title text ****/
    titleText.setString(" Inventory");
    titleText.setFont(font);
    titleText.setCharacterSize(60);
    titleText.setFillColor(sf::Color::White);
    titleText.setPosition(265, 50);

    /**** Title Bar ****/
    if (!texture.loadFromFile("./Images/Gather Homepage Banner1.png", sf::IntRect(0, 160, 800, 190)))
    {
        std::cout << "\nTitle Bar image could not be loaded from the file.\n";
    }
    texture.setSmooth(true);
    sprite.setTexture(texture);

    /**** Home Button ****/ 
    home.setButtonColor(sf::Color::Transparent);
    home.setText("");
    home.setSize({ 100, 100 });
    home.setPosition({ 670, 50 });

    /**** Settings Button ****/ 
    settings.setButtonColor(sf::Color::Transparent);
    settings.setText("");
    settings.setSize({ 100, 100 });
    settings.setPosition({ 30, 50 });

    /**** Textbox ****/
	textbox.setFont(font);
	textbox.setPosition({ 220, 400 });
	textbox.setLimit(true, 20);

    /*** Current Page ***/ 
    p = Page::CurrentPage::InventoryPage;
}

/**********************************************************
*  Draw the page to the window.                           *
***********************************************************/
void InventoryPage::drawPage(void)
{
    /**** Draw ****/
    window->draw(sprite);
    window->draw(titleText);
    textbox.drawTo(*window);
    settings.drawTo(*window);
    home.drawTo(*window);
} 

/**********************************************************
*  Perform the event operations.                          *
***********************************************************/
void InventoryPage::eventOperation(const sf::Event & event)
{
    // If a button was pressed, perform the operation tied to the button
    if (event.type == sf::Event::MouseButtonPressed)
    {
        if (settings.mouseHover(*window))           // if the settings button is pressed, change to settings page
        {
            changePage = true;
            newPage = Page::CurrentPage::SettingsPage;
        }
    }

    //Homepage Button event operation
    if (event.type == sf::Event::MouseButtonPressed)
    {
        if (home.mouseHover(*window))           // if the home button is pressed, change to home page
        {
            changePage = true;
            newPage = Page::CurrentPage::HomePage;
        }
    }
    
    // for selecting the textbox
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Return))
	{
		textbox.setSelected(true);
	}
	else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Escape))
	{
		textbox.setSelected(false);
	}

    // for typing into the textbox
    if (event.type == sf::Event::TextEntered)
    {
		textbox.type(event);
    }

    if (event.type == sf::Event::MouseButtonReleased)
    {
        if (event.mouseButton.button == sf::Mouse::Left)
        {
            if (textbox.mouseHover(*window))
            {
                textbox.setSelected(true);
                textbox.setOutlineColor(sf::Color::Black);
            }
            else
            {
                textbox.setSelected(false);
                textbox.setOutlineColor(sf::Color(192, 192, 192, 250));
            }
        }
    }
} 