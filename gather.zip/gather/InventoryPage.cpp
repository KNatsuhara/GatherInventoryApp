/********************************************************************
 * 
 * 
 * 
 * 
 * 
 *
 * 
 * ******************************************************************/

#include "InventoryPage.hpp"

// Page Components 
namespace
{
    sf::Text titleText, searchText;
    sf::Sprite sprite;
    sf::Texture texture;
    Button item1, item2, item3, item4, item5, item6, item7, item8, settings, home;
	TextBox textbox(40, sf::Color::Black, false, {400, 75});
    Page::CurrentPage p;
}

/**********************************************************
*  Create all the components for the page.                *
***********************************************************/
void InventoryPage::createPage()
{
    /**** Title text ****/
    titleText.setString(" Inventory");
    titleText.setFont(font);
    titleText.setCharacterSize(60);
    titleText.setFillColor(sf::Color::White);
    titleText.setPosition(265, 50);

    /**** Title Bar ****/
    if (!texture.loadFromFile("./Images/Gather Green Banner.png", sf::IntRect(0, 160, 800, 190)))
    {
        std::cout << "\nTitle Bar image could not be loaded from the file.\n";
    }
    texture.setSmooth(true);
    sprite.setTexture(texture);

    /**** Home Button ****/ 
    home.setButtonColor(sf::Color::Transparent);
    home.setText("");
    home.setSize({ 100, 100 });
    home.setPosition({ 670, 50 });

    /**** Settings Button ****/ 
    settings.setButtonColor(sf::Color::Transparent);
    settings.setText("");
    settings.setSize({ 100, 100 });
    settings.setPosition({ 30, 50 });

    /**** Title text ****/
    searchText.setString("Search:");
    searchText.setFont(font);
    searchText.setCharacterSize(30);
    searchText.setFillColor(sf::Color::Black);
    searchText.setPosition(75, 230);

    /**** Textbox ****/
	textbox.setFont(font);
	textbox.setPosition({ 220, 220 });
	textbox.setLimit(true, 20);

    /**** Items Button*****/
    item1.setButtonColor(sf::Color(0, 204, 136, 250));
    item1.setTextColor(sf::Color::White);
    item1.setText("Item 1");
    item1.setTextSize(30);
    item1.setSize({ 400, 75 });
    item1.setPosition({ 200, 300 });
    item1.setFont(font);

    item2.setButtonColor(sf::Color(0, 179, 119, 250));
    item2.setTextColor(sf::Color::White);
    item2.setText("Item 2");
    item2.setTextSize(30);
    item2.setSize({ 400, 75 });
    item2.setPosition({ 200, 375 });
    item2.setFont(font);

    item3.setButtonColor(sf::Color(0, 153, 102, 250));
    item3.setTextColor(sf::Color::White);
    item3.setText("Item 3");
    item3.setTextSize(30);
    item3.setSize({ 400, 75 });
    item3.setPosition({ 200, 450 });
    item3.setFont(font);

    item4.setButtonColor(sf::Color(0, 128, 85, 250));
    item4.setTextColor(sf::Color::White);
    item4.setText("Item 4");
    item4.setTextSize(30);
    item4.setSize({ 400, 75 });
    item4.setPosition({ 200, 525 });
    item4.setFont(font);

    item5.setButtonColor(sf::Color(0, 102, 68, 250));
    item5.setTextColor(sf::Color::White);
    item5.setText("Item 5");
    item5.setTextSize(30);
    item5.setSize({ 400, 75 });
    item5.setPosition({ 200, 600 });
    item5.setFont(font);

    item6.setButtonColor(sf::Color(0, 77, 51, 250));
    item6.setTextColor(sf::Color::White);
    item6.setText("Item 6");
    item6.setTextSize(30);
    item6.setSize({ 400, 75 });
    item6.setPosition({ 200, 675 });
    item6.setFont(font);

    item7.setButtonColor(sf::Color(0, 51, 34, 250));
    item7.setTextColor(sf::Color::White);
    item7.setText("Item 7");
    item7.setTextSize(30);
    item7.setSize({ 400, 75 });
    item7.setPosition({ 200, 750 });
    item7.setFont(font);

    item8.setButtonColor(sf::Color(0, 26, 17, 250));
    item8.setTextColor(sf::Color::White);
    item8.setText("Item 8");
    item8.setTextSize(30);
    item8.setSize({ 400, 75 });
    item8.setPosition({ 200, 825 });
    item8.setFont(font);




    /*** Current Page ***/ 
    p = Page::CurrentPage::InventoryPage;
}

/**********************************************************
*  Draw the page to the window.                           *
***********************************************************/
void InventoryPage::drawPage(void)
{
    /**** Draw ****/
    item1.setPosition({ 200, 300 });
    item2.setPosition({ 200, 375 });
    item3.setPosition({ 200, 450 });
    item4.setPosition({ 200, 525 });
    item5.setPosition({ 200, 600 });
    item6.setPosition({ 200, 675 });
    item7.setPosition({ 200, 750 });
    item8.setPosition({ 200, 825 });

    window->draw(sprite);
    window->draw(titleText);
    window->draw(searchText);
    item1.drawTo(*window);
    item2.drawTo(*window);
    item3.drawTo(*window);
    item4.drawTo(*window);
    item5.drawTo(*window);
    item6.drawTo(*window);
    item7.drawTo(*window);
    item8.drawTo(*window);
    textbox.drawTo(*window);
    settings.drawTo(*window);
    home.drawTo(*window);
} 

/**********************************************************
*  Perform the event operations.                          *
***********************************************************/
void InventoryPage::eventOperation(const sf::Event & event)
{
    // If a button was pressed, perform the operation tied to the button
    if (event.type == sf::Event::MouseButtonPressed)
    {
        if (settings.mouseHover(*window))           // if the settings button is pressed, change to settings page
        {
            changePage = true;
            newPage = Page::CurrentPage::SettingsPage;
        }
    }

    //Homepage Button event operation
    if (event.type == sf::Event::MouseButtonPressed)
    {
        if (home.mouseHover(*window))           // if the home button is pressed, change to home page
        {
            changePage = true;
            newPage = Page::CurrentPage::HomePage;
        }
    }
    
    // for selecting the textbox
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Return))
	{
		textbox.setSelected(true);
	}
	else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Escape))
	{
		textbox.setSelected(false);
	}

    // for typing into the textbox
    if (event.type == sf::Event::TextEntered)
    {
		textbox.type(event);
    }

    if (event.type == sf::Event::MouseButtonReleased)
    {
        if (event.mouseButton.button == sf::Mouse::Left)
        {
            if (textbox.mouseHover(*window))
            {
                textbox.setSelected(true);
                textbox.setOutlineColor(sf::Color::Black);
            }
            else
            {
                textbox.setSelected(false);
                textbox.setOutlineColor(sf::Color(192, 192, 192, 250));
            }
        }
    }

    // change color of the buttons when mouse hovers over it
    if (event.type == sf::Event::MouseMoved)
    {
        if (item1.mouseHover(*window))
        {
            item1.setButtonColor(sf::Color(77, 255, 195, 255));    //changes color
        }
        else 
        {
            item1.setButtonColor(sf::Color(0, 204, 140, 136));      // keep the color the same
        }
    }

    // If a button was pressed, perform the operation tied to the button
    if (event.type == sf::Event::MouseButtonPressed)
    {
        if (item1.mouseHover(*window))           // if the item1 button is pressed, change to about item1
        {
            changePage = true;
            newPage = Page::CurrentPage::ItemPage;
        }
    }

    // change color of the buttons when mouse hovers over it
    if (event.type == sf::Event::MouseMoved)
    {
        if (item2.mouseHover(*window))
        {
            item2.setButtonColor(sf::Color(77, 255, 195, 255));    //changes color
        }
        else 
        {
            item2.setButtonColor(sf::Color(0, 179, 119, 250));      // keep the color the same
        }
    }

    // If a button was pressed, perform the operation tied to the button
    if (event.type == sf::Event::MouseButtonPressed)
    {
        if (item2.mouseHover(*window))           // if the item2 button is pressed, change to about item2
        {
            changePage = true;
            newPage = Page::CurrentPage::ItemPage;
        }
    }

    // change color of the buttons when mouse hovers over it
    if (event.type == sf::Event::MouseMoved)
    {
        if (item3.mouseHover(*window))
        {
            item3.setButtonColor(sf::Color(77, 255, 195, 255));    //changes color
        }
        else 
        {
            item3.setButtonColor(sf::Color(0, 153, 102, 250));      // keep the color the same
        }
    }

    // If a button was pressed, perform the operation tied to the button
    if (event.type == sf::Event::MouseButtonPressed)
    {
        if (item3.mouseHover(*window))           // if the item3 button is pressed, change to about item3
        {
            changePage = true;
            newPage = Page::CurrentPage::ItemPage;
        }
    }

    // change color of the buttons when mouse hovers over it
    if (event.type == sf::Event::MouseMoved)
    {
        if (item4.mouseHover(*window))
        {
            item4.setButtonColor(sf::Color(77, 255, 195, 255));    //changes color
        }
        else 
        {
            item4.setButtonColor(sf::Color(0, 128, 85, 250));      // keep the color the same
        }
    }

    // If a button was pressed, perform the operation tied to the button
    if (event.type == sf::Event::MouseButtonPressed)
    {
        if (item4.mouseHover(*window))           // if the item4 button is pressed, change to about item4
        {
            changePage = true;
            newPage = Page::CurrentPage::ItemPage;
        }
    }

    // change color of the buttons when mouse hovers over it
    if (event.type == sf::Event::MouseMoved)
    {
        if (item5.mouseHover(*window))
        {
            item5.setButtonColor(sf::Color(77, 255, 195, 255));    //changes color
        }
        else 
        {
            item5.setButtonColor(sf::Color(0, 102, 68, 250));      // keep the color the same
        }
    }

    // If a button was pressed, perform the operation tied to the button
    if (event.type == sf::Event::MouseButtonPressed)
    {
        if (item5.mouseHover(*window))           // if the item5 button is pressed, change to about item5
        {
            changePage = true;
            newPage = Page::CurrentPage::ItemPage;
        }
    }

    // change color of the buttons when mouse hovers over it
    if (event.type == sf::Event::MouseMoved)
    {
        if (item6.mouseHover(*window))
        {
            item6.setButtonColor(sf::Color(77, 255, 195, 255));    //changes color
        }
        else 
        {
            item6.setButtonColor(sf::Color(0, 77, 51, 250));      // keep the color the same
        }
    }

    // If a button was pressed, perform the operation tied to the button
    if (event.type == sf::Event::MouseButtonPressed)
    {
        if (item6.mouseHover(*window))           // if the item6 button is pressed, change to about item6
        {
            changePage = true;
            newPage = Page::CurrentPage::ItemPage;
        }
    }

    // change color of the buttons when mouse hovers over it
    if (event.type == sf::Event::MouseMoved)
    {
        if (item7.mouseHover(*window))
        {
            item7.setButtonColor(sf::Color(77, 255, 195, 255));    //changes color
        }
        else 
        {
            item7.setButtonColor(sf::Color(0, 51, 34, 250));      // keep the color the same
        }
    }

    // If a button was pressed, perform the operation tied to the button
    if (event.type == sf::Event::MouseButtonPressed)
    {
        if (item7.mouseHover(*window))           // if the item7 button is pressed, change to about item7
        {
            changePage = true;
            newPage = Page::CurrentPage::ItemPage;
        }
    }

    // change color of the buttons when mouse hovers over it
    if (event.type == sf::Event::MouseMoved)
    {
        if (item8.mouseHover(*window))
        {
            item8.setButtonColor(sf::Color(77, 255, 195, 255));    //changes color
        }
        else 
        {
            item8.setButtonColor(sf::Color(0, 26, 17, 250));      // keep the color the same
        }
    }

    // If a button was pressed, perform the operation tied to the button
    if (event.type == sf::Event::MouseButtonPressed)
    {
        if (item8.mouseHover(*window))           // if the item8 button is pressed, change to about item8
        {
            changePage = true;
            newPage = Page::CurrentPage::ItemPage;
        }
    }
} 