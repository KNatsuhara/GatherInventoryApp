/********************************************************************
 * 
 * 
 * 
 * 
 * 
 * 
 * ******************************************************************/

#include "Page.hpp"

// Default Constructor
Page::Page() : font(sf::Font()), window(nullptr) {    }

// Destructor
Page::~Page() {    }

// Set font
void Page::setFont (const sf::Font &f)
{
    font = f;
}

// Set window
void Page::setWindow (sf::RenderWindow &w)
{
    window = &w;
}

// Change the boolean for change page 
void Page::setChange(const bool &change)
{
    changePage = change;
}

// Return if the user is changing the page
bool Page::getChange(void)
{
    return changePage;
}