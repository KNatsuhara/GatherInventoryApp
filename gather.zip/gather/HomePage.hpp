/********************************************************************
 * 
 * 
 * 
 * 
 * 
 * 
 * ******************************************************************/

#ifndef HOMEPAGE_HPP
#define HOMEPAGE_HPP

#include "Page.hpp"

#include "Button.hpp"
#include "TextBox.hpp"

#include <SFML/Graphics.hpp>

// Class for the HomePage of the app -> first page when the app opens
class HomePage : public Page
{
public: 
    // Default Constructor
    HomePage() : Page() {   }

    // Create all the components for the page
    virtual void createPage();

    // Draw the page to the window
    virtual void drawPage();

    // Perform the event operations
    virtual void eventOperation(const sf::Event & event, Inventory &inventory, Item &item);
    
};

#endif