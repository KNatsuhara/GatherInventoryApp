/********************************************************************
 * 
 * 
 * 
 * 
 * 
 * 
 * ******************************************************************/

#ifndef TEXTBOX_HPP
#define TEXTBOX_HPP

// Libraries
#include <iostream>
#include <sstream>
#include <string>
#include <SFML/Graphics.hpp>

//Values for using the delete, enter, and escape keys
#define DELETE 8
#define ENTER 13
#define ESC 27

// TextBox class
class TextBox
{
private:
	//private variables 
	sf::Text textbox;
    sf::RectangleShape border;
	std::ostringstream text;
	bool isSelected = false;
	bool hasLimit = false;
	int limit;

public:

    // Constructor
	TextBox(const int &size, const sf::Color &color, const bool &selected, const sf::Vector2f &borderSize);

    // Setters
	void setFont(const sf::Font& font);
    void setPosition(const sf::Vector2f &pos);
	void setLimit(const bool &check, const int &lim);
	void setSelected(const bool &sel);
    void setOutline(const sf::Vector2f &pos);
    void setOutlineColor(const sf::Color &c);

    // Get the text typed by the user 
    std::string getText();

    // Allows for input of characters 
    void input(const int &charTyped);

    // Allows for deleted characters to be removed
    void deleteChar();

    // Handle the typing of characters by the user  
	void type(const sf::Event &input);

    // Draw the text box to the window
    void drawTo(sf::RenderWindow& window);

    // Mouse operations ->check if the mouse is over the textbox
    bool mouseHover(sf::RenderWindow &window);

};

#endif