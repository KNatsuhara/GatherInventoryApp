#include <iostream>
#include <iomanip>

class Item
{
private:
    std::string itemName;
    std::string category;
    std::string expirationDate;
    double price;
    int quantity;
public:
    Item() //Constructor
    {
        itemName = "Empty";
        category = "";
        expirationDate = "";
        price = 0;
        quantity = 0;
    }

    Item(std::string itemName, std::string category, std::string expirationDate, double price, int quantity) //Parametized Constructor
    {
        this->itemName = itemName;
        this->category = category;
        this->expirationDate = expirationDate;
        this->price = price;
        this->quantity = quantity;
    }

    ~Item() //Destructor
    {
        itemName = "";
        category = "";
        expirationDate = "";
        price = 0;
        quantity = 0;
    }

    Item(const Item &copy) //Copy Constructor
    {
        *this = copy;
    }

    Item& operator= (const Item &copy) //Copy Assignment Operator
    {
        if(this != &copy)
        {
            this->itemName = copy.itemName;
            this->category = copy.category;
            this->expirationDate = copy.expirationDate;
            this->price = copy.price;
            this->quantity = copy.quantity;
        }
        return *this;
    }

    Item(Item &&obj) //Move Constructor
    {
        this->itemName = obj.itemName;
        this->category = obj.category;
        this->expirationDate = obj.expirationDate;
        this->price = obj.price;
        this->quantity = obj.quantity;

        obj.itemName = "";
        obj.category = "";
        obj.expirationDate = "";
        obj.price = 0;
        obj.quantity = 0;
    }

    Item operator= (Item &&obj) //Move Assignment Operator
    {
        if(this != &obj)
        {
            if(this->itemName !=  "")
            {
                this->itemName = "";
                this->category = "";
                this->expirationDate = "";
                this->price = 0;
                this->quantity = 0;
            }

            this->itemName = obj.itemName;
            this->category = obj.category;
            this->expirationDate = obj.expirationDate;
            this->price = obj.price;
            this->quantity = obj.quantity;

            obj.itemName = "";
            obj.category = "";
            obj.expirationDate = "";
            obj.price = 0;
            obj.quantity = 0;
        }

        return *this;
    }

    friend std::ostream& operator << (std::ostream& output, const Item &data)
    {
        output << "Item Name: " << data.itemName << " Category:" << data.category << " Expiration Date: " << data.expirationDate 
            << " Price : $" << std::fixed << std::setprecision(2) << data.price << " Quantity: " << data.quantity;
        return output;
    }

    std::string getItemName() {return itemName;}
    std::string getCategory() {return category;}
    std::string getExpirationDate() {return expirationDate;}
    double getPrice() {return price;}
    int getQuantity() {return quantity;}

    void setItemName(std::string name) {this->itemName = name;}
    void setCategory(std::string category) {this->category = category;}
    void setExpirationDate(std::string expirationDate) {this->expirationDate = expirationDate;}
    void setPrice(double price) {this->price = price;}
    void setQuantity(int quantity) {this->quantity = quantity;}
};