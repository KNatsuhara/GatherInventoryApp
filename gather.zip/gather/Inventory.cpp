#include "Inventory.hpp"

//Default constructor
Inventory::Inventory(bool openFile /*=true*/, std::string fileName /*="inventoryData.csv"*/)
{
	if(openFile)
		readCSV(fileName);
}
Inventory::~Inventory()
{
	writeCSV("inventoryData.csv");
	inv.clear();
}
//Insert individual member values
void Inventory::insert(std::string name, std::string category, std::string exp, double price, int quantity){
	Item temp{name, category, exp, price, quantity};
	insert(temp);
}
//Insert Item object
void Inventory::insert(Item x){
	inv.insert({x.getItemName(), x}); 
}
//Legacy find 
Item* Inventory::find(std::string name){
    return &inv.at(name);
}

//Check if map contains an item with a given key
bool Inventory::contains(std::string name){
	Item result;
	// bool found = find(name, result);
	// return found;
	try
	{
		result = inv.at(name);
		return true;
	}
	catch(const std::exception& e)
	{
		return false; 
	}
	
}
/*
Search map for keys that start with a given string.
Returns pointer to an array of 8 Items.
If fewer than 8 matches found, array is populated with empty Items.
*/
Item* Inventory::search(std::string name){
	int len = 8, count = 0;
	bool match = true;
	//Dynamic allocation allows return of array
	Item* temp = new Item[len];

	//Check map for similar keys
	for(auto i : inv){
		match = false;
		// //startsWith()
		// for(int j = 0; j < name.size(); ++j){
		// 	if(name[j] == i.first[j]){
		// 		match = true;
		// 	}
		// 	else{
		// 		match = false;
		// 		break; 
		// 	}
		// }
		//startsWith() - could be changed to check contains() instead of startsWith()
		if(i.first.find(name) == 0) 
			match = true;
		//Characters match and array is not full
		if(match && count < len){
			*(temp + count) = i.second;
			++count;
		}
	}
	//Fill array with empty Items
	while(count < len){
		*(temp + count) = Item();
		++count;
	}
	return temp;
}
void Inventory::remove(std::string name){
	//If statement may be unnecessary 
	if(contains(name)){
		inv.erase(name);
	}
}
//Update name for an item.
//Creates a new item with updated name and inserts it after deleting the old one
//Throws std::out_of_range if not found
void Inventory::updateName(std::string name, std::string n){ //Test
	//Find item
	auto result = inv.find(name);
	if(result != inv.end()){
		Item temp;
		//Duplicate item
		temp = result->second;
		//Update name
		temp.setItemName(n);
		//Erase original
		inv.erase(result); //Verify good
		//Insert new 
		insert(temp);
	}
}
//Update category for an item.
//Throws std::out_of_range if not found
void Inventory::updateCategory(std::string name, std::string cat){
	inv.at(name).setCategory(cat);
}
//Update expiration date for an item.
//Throws std::out_of_range if not found
void Inventory::updateExpiration(std::string name, std::string exp){
	inv.at(name).setExpirationDate(exp);
}
//Update price for an item.
//Throws std::out_of_range if not found
void Inventory::updatePrice(std::string name, double p){
	inv.at(name).setPrice(p);
}
//Update quantity for an item.
//Throws std::out_of_range if not found
void Inventory::updateQuantity(std::string name, int q){
	inv.at(name).setQuantity(q);
}
//Edit any one value for an item.
//Assumes item exists in map. Throws std::out_of_range if not found.
void Inventory::updateItem(std::string name, int operation, std::string data){
	
	switch (operation)
	{
	case 1: //name
		updateName(name, data);
		break;
	case 2: //category
		updateCategory(name, data);
		break;
	case 3: //expiration date
		updateExpiration(name, data);
		break;
	case 4: //price
		updatePrice(name, std::stod(data));
		break;
	case 5: //quantity
		updateQuantity(name, std::stoi(data));
		break;
	
	default:
		break;
	}
}
//Legacy function. Allow user to choose an item to edit. Text-based.
void Inventory::updateItem(){
	std::string name = "";
	bool cont = true, accepted = false;
	char inp; 
	int option = 0;
	Item temp;
	std::string buff = ""; 

	//Input validation for name
	do{
		std::cout << "Enter the name of the item to be edited: ";
		getline(std::cin, name);
		if(contains(name)){
			find(name); 
			cont = true;
		}
		else{
			//Input validation for whether to try again
			do{
				std::cout << "Value not found. Choose another value? (y/n) ";
				std::cin >> inp;
				if(inp == 'y'){
					cont = false; 
					accepted = true; 
				}
				else if(inp == 'n'){
					return;
				}
				else{
					std::cout << "Invalid entry.\n"; 
					accepted = false; 
				}
			} while (!accepted);
		}
	} while (!cont);
	//Input validation for menu selection 
	do
	{
		std::cout << "Choose the property to be edited: \n";
		std::cout << "1. Name\n";
		std::cout << "2. Category\n";
		std::cout << "3. Expiration Date\n";
		std::cout << "4. Price\n";
		std::cout << "5. Quantity\n"; 

		std::cin >> option; 
	
		if(option < 1 || option > 5)
			std::cout << "Invalid entry.\n"; 

	} while (option < 1 || option > 5);
	
	//Add input validation loops
	switch (option)
	{
	case 1:
		std::cout << "Enter the new name: ";
		getline(std::cin, buff);
		// temp = *old;
		// temp.setItemName(buff);
		// remove(old->getItemName());
		// insert(temp); 
		updateItem(name, option, buff);
		break;
	case 2:
		std::cout << "Enter the new category: ";
		getline(std::cin, buff);
		// old->setCategory(buff);
		updateItem(name, option, buff);
		break;
	case 3:
		std::cout << "Enter the new expiration date: ";
		getline(std::cin, buff);
		// old->setExpirationDate(buff);
		updateItem(name, option, buff);
		break;
	case 4:
		std::cout << "Enter the new price: ";
		getline(std::cin, buff);
		// old->setPrice(std::stod(buff));
		updateItem(name, option, buff);
		break;
	case 5:
		std::cout << "Enter the new quantity: ";
		std::cin >> std::ws;
		getline(std::cin, buff);
		// old->setQuantity(std::stoi(buff)); 
		updateItem(name, option, buff);
		break;
	
	default:
		break;
	}
}

//Print entire map to the given stream, default is std::cout
void Inventory::printAlphabetical(std::ostream& out /*= std::cout*/){
	for(auto i : inv)
		out << i.second << std::endl; 
}

//Read inventory data from a CSV file
bool Inventory::readCSV(std::string filename)
{//Adapted from a previous assignment

	//OPEN CSV
	std::fstream inFile;
	inFile.open(filename, std::ios::in);

	//Confirm open
	if(inFile.is_open()){ 
		Item buff;

		std::string temp;
		while (getline(inFile, temp, ',')) 
		{
			//Name
			buff.setItemName(temp);
			//Category
			getline(inFile,temp,',');
			buff.setCategory(temp);
			//Expiration date
			getline(inFile,temp,',');
			buff.setExpirationDate(temp);
			//Price
			getline(inFile,temp,',');
			buff.setPrice(std::stod(temp));
			//Quantity
			getline(inFile,temp,'\n');
			buff.setQuantity(std::stoi(temp));

			//Insert
			insert(buff);
		}
		inFile.close();
		std::cout << "Finished reading data from file.\n";
		return true;
	}
	else{
		std::cout << "Input file could not be opened.\n";
		return false;
	}
}
void Inventory::writeCSV(std::string filename){
	
	//Open CSV
	std::fstream outFile;
	outFile.open(filename, std::ios::out);

	//Confirm open
	if(outFile.is_open()){
		for(auto i : inv){
			outFile << 
			i.second.getItemName() << "," << 
			i.second.getCategory() << "," << 
			i.second.getExpirationDate() << "," << 
			i.second.getPrice() << "," << 
			i.second.getQuantity() << std::endl;
		}
		std::cout << "Finished writing data to file.\n";
	}
	else{
		std::cout << "Output file could not be opened.\n";
	}
}

Item* Inventory::getKItems(int k)
{
    Item* temp = new Item[k];
    int count = 0;

    //Add items to array while map is not empty
    for(auto i : inv){
        if(count < k){
            *(temp + count) = i.second;
            ++count;
        }
        else 
            break;
    }

    //Add empty items to array if not full
    while(count < k){
        *(temp + count) = Item();
        ++count;
    }

    return temp;
}

int Inventory::getSize(){
    return inv.size();
}

