/********************************************************************
 * 
 * 
 * 
 * 
 * 
 * 
 * ******************************************************************/

#ifndef USERPAGE_HPP
#define USERPAGE_HPP

#include "Page.hpp"

#include "Button.hpp"
#include "TextBox.hpp"

#include <SFML/Graphics.hpp>

// Class for the UserPage of the app -> first page when the app opens
class UserPage : public Page
{
public: 
    // Default Constructor
    UserPage() : Page() {   }

    // Create all the components for the page
    virtual void createPage();

    // Draw the page to the window
    virtual void drawPage();

    // Perform the event operations
    virtual void eventOperation(const sf::Event & event);
    
};

#endif