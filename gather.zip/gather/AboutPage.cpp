/********************************************************************
 * 
 * 
 * 
 * 
 * 
 * 
 * ******************************************************************/

#include "AboutPage.hpp"

// Page Components 
namespace
{
    sf::Text titleText;
    sf::Sprite sprite;
    sf::Texture texture;
    Button items, inventory, about, quit, settings, home;
	TextBox textbox(40, sf::Color::Black, false, {400, 75});
}

/**********************************************************
*  Create all the components for the page.                *
***********************************************************/
void AboutPage::createPage()
{
    /**** Title text ****/
    titleText.setString("  About");
    titleText.setFont(font);
    titleText.setCharacterSize(60);
    titleText.setFillColor(sf::Color::White);
    titleText.setPosition(265, 50);

    /**** Title Bar ****/
    if (!texture.loadFromFile("./Images/Gather Homepage Banner1.png", sf::IntRect(0, 160, 800, 190)))
    {
        std::cout << "\nTitle Bar image could not be loaded from the file.\n";
    }
    texture.setSmooth(true);
    sprite.setTexture(texture);

    /**** Items Button*****/
    items.setButtonColor(sf::Color(140, 140, 140, 250));
    items.setTextColor(sf::Color::White);
    items.setText("        Items");
    items.setTextSize(40);
    items.setSize({ 400, 75 });
    items.setPosition({ 200, 300 });
    items.setFont(font);

    /**** Inventory Button *****/
    inventory.setButtonColor(sf::Color(140, 140, 140, 250));
    inventory.setTextColor(sf::Color::White);
    inventory.setText("      Inventory");
    inventory.setTextSize(40);
    inventory.setSize({ 400, 75 });
    inventory.setPosition({ 200, 400 });
    inventory.setFont(font);

    /**** About Button *****/
    about.setButtonColor(sf::Color(140, 140, 140, 250));
    about.setTextColor(sf::Color::White);
    about.setText("       About");
    about.setTextSize(40);
    about.setSize({ 400, 75 });
    about.setPosition({ 200, 500 });
    about.setFont(font);

    /**** Exit Button *****/
    quit.setButtonColor(sf::Color(140, 140, 140, 250));
    quit.setTextColor(sf::Color::White);
    quit.setText("        Exit");
    quit.setTextSize(40);
    quit.setSize({ 400, 75 });
    quit.setPosition({ 200, 600 });
    quit.setFont(font);

    /**** Home Button ****/ 
    home.setButtonColor(sf::Color::Transparent);
    home.setText("");
    home.setSize({ 100, 100 });
    home.setPosition({ 670, 50 });

    /**** Settings Button ****/ 
    settings.setButtonColor(sf::Color::Transparent);
    settings.setText("");
    settings.setSize({ 100, 100 });
    settings.setPosition({ 30, 50 });

    /**** Textbox ****/
	// textbox.setFont(font);
	// textbox.setPosition({ 220, 400 });
	// textbox.setLimit(true, 20);

}

/**********************************************************
*  Draw the page to the window.                           *
***********************************************************/
void AboutPage::drawPage(void)
{
    /**** Draw ****/
    window->draw(sprite);
    window->draw(titleText);
    //textbox.drawTo(*window);
    items.drawTo(*window);
    settings.drawTo(*window);
    inventory.drawTo(*window);
    about.drawTo(*window);
    quit.drawTo(*window);
} 

/**********************************************************
*  Perform the event operations.                          *
***********************************************************/
void AboutPage::eventOperation(const sf::Event & event)
{
    // change color of the buttons when mouse hovers over it
    if (event.type == sf::Event::MouseMoved)
    {
        if (items.mouseHover(*window))
        {
            items.setButtonColor(sf::Color(155, 155, 206, 255));    //changes color
        }
        else 
        {
            items.setButtonColor(sf::Color(140, 140, 140, 250));      // keep the color the same
        }
    }

    // If a button was pressed, perform the operation tied to the button
    if (event.type == sf::Event::MouseButtonPressed)
    {
        if (items.mouseHover(*window))           // if the item button is pressed, change to items page
        {
            changePage = true;
            newPage = Page::CurrentPage::ItemPage;
        }
    }

    // change color of the buttons when mouse hovers over it
    if (event.type == sf::Event::MouseMoved)
    {
        if (inventory.mouseHover(*window))
        {
            inventory.setButtonColor(sf::Color(155, 155, 206, 255));    //changes color
        }
        else 
        {
            inventory.setButtonColor(sf::Color(140, 140, 140, 250));      // keep the color the same
        }
    }

    // If a button was pressed, perform the operation tied to the button
    if (event.type == sf::Event::MouseButtonPressed)
    {
        if (inventory.mouseHover(*window))           // if the item button is pressed, change to items page
        {
            changePage = true;
            newPage = Page::CurrentPage::InventoryPage;
        }
    }

    // If a button was pressed, perform the operation tied to the button
    if (event.type == sf::Event::MouseButtonPressed)
    {
        if (settings.mouseHover(*window))           // if the settings button is pressed, change to settings page
        {
            changePage = true;
            newPage = Page::CurrentPage::SettingsPage;
        }
    }

    if (event.type == sf::Event::MouseButtonPressed)
    {
        if (home.mouseHover(*window))           // if the home button is pressed, change to home page
        {
            changePage = true;
            newPage = Page::CurrentPage::HomePage;
        }
    }
    
    // for selecting the textbox
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Return))
	{
		textbox.setSelected(true);
	}
	else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Escape))
	{
		textbox.setSelected(false);
	}

    // for typing into the textbox
    if (event.type == sf::Event::TextEntered)
    {
		textbox.type(event);
    }

    if (event.type == sf::Event::MouseButtonReleased)
    {
        if (event.mouseButton.button == sf::Mouse::Left)
        {
            if (textbox.mouseHover(*window))
            {
                textbox.setSelected(true);
                textbox.setOutlineColor(sf::Color::Black);
            }
            else
            {
                textbox.setSelected(false);
                textbox.setOutlineColor(sf::Color(192, 192, 192, 250));
            }
        }
    }
} 