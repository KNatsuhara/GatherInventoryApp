/********************************************************************
 * 
 * 
 * 
 * 
 * 
 * 
 * ******************************************************************/

#ifndef INVENTORYPAGE_HPP
#define INVENTORYPAGE_HPP

#include "Page.hpp"

#include "Button.hpp"
#include "TextBox.hpp"

#include <SFML/Graphics.hpp>

// Class for the InventoryPage of the app -> first page when the app opens
class InventoryPage : public Page
{
public: 
    // Default Constructor
    InventoryPage() : Page() {   }

    // Create all the components for the page
    virtual void createPage();

    // Draw the page to the window
    virtual void drawPage();

    // Perform the event operations
    virtual void eventOperation(const sf::Event & event, Inventory &inventory, Item &item);
    
};

#endif