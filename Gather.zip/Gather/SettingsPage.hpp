/********************************************************************
 * 
 * 
 * 
 * 
 * 
 * 
 * ******************************************************************/

#ifndef SETTINGSPAGE_HPP
#define SETTINGSPAGE_HPP

#include "Page.hpp"

#include "Button.hpp"
#include "TextBox.hpp"

#include <SFML/Graphics.hpp>

// Class for the Settings page of the app
class SettingsPage : public Page
{
public: 
    // Default Constructor
    SettingsPage() : Page() {   }

    // Create all the components for the page
    virtual void createPage();

    // Draw the page to the window
    virtual void drawPage();

    // Perform the event operations
    virtual void eventOperation(const sf::Event & event);
    
};

#endif