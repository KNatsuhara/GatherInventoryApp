/********************************************************************
 * 
 * 
 * 
 * 
 * 
 * 
 * ******************************************************************/

#include "UserPage.hpp"

// Page Components 
namespace
{
    sf::Text titleText;
    sf::Sprite sprite;
    sf::Texture texture;
    Button items, inventory, about, quit, settings, home;
}

/**********************************************************
*  Create all the components for the page.                *
***********************************************************/
void UserPage::createPage()
{
    /**** Title text ****/
    titleText.setString("Users");
    titleText.setFont(font);
    titleText.setCharacterSize(60);
    titleText.setFillColor(sf::Color::White);
    titleText.setPosition(400 - titleText.getLocalBounds().width / 2, 50);

    /**** Title Bar ****/
    if (!texture.loadFromFile("./Images/Gather Homepage Banner1.png", sf::IntRect(0, 160, 800, 190)))
    {
        std::cout << "\nTitle Bar image could not be loaded from the file.\n";
    }
    texture.setSmooth(true);
    sprite.setTexture(texture);

    /**** Items Button*****/
    items.setButtonColor(sf::Color(140, 140, 140, 250));
    items.setTextColor(sf::Color::White);
    items.setText("Items");
    items.setTextSize(40);
    items.setSize({ 400, 75 });
    items.setPosition({ 200, 300 });
    items.setFont(font);

    /**** Inventory Button *****/
    inventory.setButtonColor(sf::Color(140, 140, 140, 250));
    inventory.setTextColor(sf::Color::White);
    inventory.setText("Inventory");
    inventory.setTextSize(40);
    inventory.setSize({ 400, 75 });
    inventory.setPosition({ 200, 400 });
    inventory.setFont(font);

    /**** About Button *****/
    about.setButtonColor(sf::Color(140, 140, 140, 250));
    about.setTextColor(sf::Color::White);
    about.setText("About");
    about.setTextSize(40);
    about.setSize({ 400, 75 });
    about.setPosition({ 200, 500 });
    about.setFont(font);

    /**** Exit Button *****/
    quit.setButtonColor(sf::Color(140, 140, 140, 250));
    quit.setTextColor(sf::Color::White);
    quit.setText("Exit");
    quit.setTextSize(40);
    quit.setSize({ 400, 75 });
    quit.setPosition({ 200, 600 });
    quit.setFont(font);

    /**** Home Button ****/ 
    home.setButtonColor(sf::Color::Transparent);
    home.setText("");
    home.setSize({ 100, 100 });
    home.setPosition({ 670, 50 });

    /**** Settings Button ****/ 
    settings.setButtonColor(sf::Color::Transparent);
    settings.setText("");
    settings.setSize({ 100, 100 });
    settings.setPosition({ 30, 50 });

}

/**********************************************************
*  Draw the page to the window.                           *
***********************************************************/
void UserPage::drawPage(void)
{
    items.setPosition({200, 300});
    inventory.setPosition({ 200, 400 });
    about.setPosition({ 200, 500 });
    quit.setPosition({ 200, 600 });

    /**** Draw ****/
    window->draw(sprite);
    window->draw(titleText);
    items.drawTo(*window);
    settings.drawTo(*window);
    inventory.drawTo(*window);
    about.drawTo(*window);
    quit.drawTo(*window);
} 

/**********************************************************
*  Perform the event operations.                          *
***********************************************************/
void UserPage::eventOperation(const sf::Event & event)
{
    // Change color of the buttons when mouse hovers over it
    if (event.type == sf::Event::MouseMoved)
    {
        if (about.mouseHover(*window))
            about.setButtonColor(sf::Color(155, 155, 206, 255));   // changes color of about button
        else 
            about.setButtonColor(sf::Color(140, 140, 140, 250));   // keep the color the same

        if (inventory.mouseHover(*window))
            inventory.setButtonColor(sf::Color(155, 155, 206, 255));    //changes color of inventory button
        else 
            inventory.setButtonColor(sf::Color(140, 140, 140, 250));    // keep the color the same

        if (quit.mouseHover(*window))
            quit.setButtonColor(sf::Color(155, 155, 206, 255));    //changes color of inventory button
        else 
            quit.setButtonColor(sf::Color(140, 140, 140, 250));    // keep the color the same

        if (items.mouseHover(*window))
            items.setButtonColor(sf::Color(155, 155, 206, 255));    //changes color of inventory button
        else 
            items.setButtonColor(sf::Color(140, 140, 140, 250));    // keep the color the same
    }

    // If a button was pressed, perform the operation tied to the button
    if (event.type == sf::Event::MouseButtonPressed)
    {
        if (settings.mouseHover(*window))       // if the settings button is pressed, change to settings page
        {
            changePage = true;
            newPage = Page::CurrentPage::SettingsPage;
        }
        if (home.mouseHover(*window))           // if the home button is pressed, change to home page
        {
            changePage = true;
            newPage = Page::CurrentPage::HomePage;
        }
        if (about.mouseHover(*window))           // if the about button is pressed, change to about page
        {
            changePage = true;
            newPage = Page::CurrentPage::AboutPage;
        }
        if (inventory.mouseHover(*window))           // if the item button is pressed, change to items page
        {
            changePage = true;
            newPage = Page::CurrentPage::InventoryPage;
        }
        if (items.mouseHover(*window))           // if the item button is pressed, change to items page
        {
            changePage = true;
            newPage = Page::CurrentPage::ItemPage;
        }
        if (quit.mouseHover(*window))
        {;
            (*window).close();
        }
    }

    // Press Esc to exit the application
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Escape))
	{
		(*window).close();              // close window
	}
} 