/********************************************************************
 * 
 * 
 * 
 * 
 * 
 * 
 * ******************************************************************/

#include "Button.hpp"

//Default Constructor
Button::Button() {  }
    
//Constructor
Button::Button(const sf::Color &textColor, const sf::Color &buttonColor, const int &sizeOfCharacters, const std::string &t, const sf::Vector2f &buttonSize)
{
    button.setFillColor(buttonColor);		// initialize values
    button.setSize(buttonSize);

    text.setString(t);
	text.setFillColor(textColor);
	text.setCharacterSize(sizeOfCharacters);
	text.setStyle(sf::Text::Bold);
}

// Destructor
Button::~Button() {	}

//Set the font 
void Button::setFont(const sf::Font &setFont)
{
	text.setFont(setFont);
}

// Sets the background square color for the button 
void Button::setButtonColor(const sf::Color &color)
{
	button.setFillColor(color);
}

// Sets the text color for the button 
void Button::setTextColor(const sf::Color &color)
{
	text.setFillColor(color);
}

// Set the text string of the button
void Button::setText(const std::string &s)
{
    text.setString(s);
}

// Set the size of the button
void Button::setSize(const sf::Vector2f &size)
{
    button.setSize(size);
}

// set the character size 
void Button::setTextSize(const int &s)
{
    text.setCharacterSize(s);
}

// Button Position & Text Position
void Button::setPosition(const sf::Vector2f &pos)
{
	button.setPosition(pos);
	this->setTextPosition(pos);
}

// Text Position
void Button::setTextPosition(const sf::Vector2f &pos)
{
	float xPos = pos.x + (button.getLocalBounds().width / 2) - (text.getLocalBounds().width / 2);
	float yPos = pos.y + (button.getLocalBounds().height / 2) - (text.getLocalBounds().height / 2);
	text.setPosition({xPos, yPos - 10});
}

// Draw button and text to window
void Button::drawTo(sf::RenderWindow &window)
{
	window.draw(button);
	window.draw(text);
}

// Mouse operations -> check if the mouse is hovering over the button
bool Button::mouseHover(sf::RenderWindow &window)
{
	float mousePosX = sf::Mouse::getPosition(window).x;
	float mousePosY = sf::Mouse::getPosition(window).y;
    bool hover = button.getGlobalBounds().contains(mousePosX, mousePosY);
    return hover;
}