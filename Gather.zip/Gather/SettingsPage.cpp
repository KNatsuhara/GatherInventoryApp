/********************************************************************
 * 
 * 
 * 
 * 
 * 
 * 
 * ******************************************************************/

#include "SettingsPage.hpp"

namespace
{
    sf::Text titleText;
    sf::Texture texture;
    sf::Sprite sprite;
    Button editProfile, homePageButton;
}

// Create all the components for the page
void SettingsPage::createPage()
{
    /**** Title Text ****/ 
    titleText.setString("Settings");
    titleText.setFont(font);
    titleText.setCharacterSize(60);
    titleText.setFillColor(sf::Color::White);
    titleText.setPosition(400 - titleText.getLocalBounds().width / 2, 50);


    /**** Title Bar ****/
    if (!texture.loadFromFile("./Images/Gather_Setting_Banner.png", sf::IntRect(0, 160, 800, 190)))
    {
        std::cout << "\nTitle Bar image could not be loaded from the file.\n";
    }
    texture.setSmooth(true);
    sprite.setTexture(texture);

    /*** Button for the edit profile ***/
    editProfile.setButtonColor(sf::Color(123, 187, 249, 250));
    editProfile.setTextColor(sf::Color::White);
    editProfile.setText("Edit Profile");
    editProfile.setTextSize(40);
    editProfile.setSize({ 400, 75 });
    editProfile.setPosition({ 200, 300 });
    editProfile.setFont(font);

    /**** Home Button ****/ 
    homePageButton.setButtonColor(sf::Color::Transparent);
    homePageButton.setText("");
    homePageButton.setSize({ 100, 100 });
    homePageButton.setPosition({ 670, 45 });
}

// Draw the page to the window
void SettingsPage::drawPage()
{
    editProfile.setPosition({ 200, 300 });

    window->draw(sprite);
    window->draw(titleText);
    editProfile.drawTo(*window);
    homePageButton.drawTo(*window);
}

// Perform the event operations
void SettingsPage::eventOperation(const sf::Event & event)
{
    // change color of the buttons when mouse hovers over it
    if (event.type == sf::Event::MouseMoved)
    {
        if (editProfile.mouseHover(*window))
            editProfile.setButtonColor(sf::Color(160, 197, 250, 200));    //changes color
        else 
            editProfile.setButtonColor(sf::Color(123, 187, 249, 250));      // keep the color the same
    }

    // If a button was pressed, perform the operation tied to the button
    if (event.type == sf::Event::MouseButtonPressed)
    {
        if (homePageButton.mouseHover(*window))        
        {
            changePage = true;
            newPage = Page::CurrentPage::HomePage;
        }
    }
}