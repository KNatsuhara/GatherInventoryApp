/********************************************************************
 * 
 * 
 * 
 * 
 * 
 * 
 * ******************************************************************/

#include "ItemPage.hpp"

// Page Components 
namespace
{
    sf::Text titleText;
    sf::Sprite sprite;
    sf::Texture texture;
    Button b, settings, home;
	TextBox textbox(40, sf::Color::Black, false, {400, 75});
}

/**********************************************************
*  Create all the components for the page.                *
***********************************************************/
void ItemPage::createPage()
{
    /**** Title text ****/
    titleText.setString("Items");
    titleText.setFont(font);
    titleText.setCharacterSize(60);
    titleText.setFillColor(sf::Color::White);
    titleText.setPosition(400 - titleText.getLocalBounds().width / 2, 50);

    /**** Title Bar ****/
    if (!texture.loadFromFile("./Images/Gather Homepage Banner1.png", sf::IntRect(0, 160, 800, 190)))
    {
        std::cout << "\nTitle Bar image could not be loaded from the file.\n";
    }
    texture.setSmooth(true);
    sprite.setTexture(texture);

    /**** Button *****/
    b.setButtonColor(sf::Color(140, 140, 140, 250));
    b.setTextColor(sf::Color::White);
    b.setText("");
    b.setTextSize(40);
    b.setSize({ 400, 75 });
    b.setPosition({ 200, 300 });
    b.setFont(font);

    /**** Home Button ****/ 
    home.setButtonColor(sf::Color::Transparent);
    home.setText("");
    home.setSize({ 100, 100 });
    home.setPosition({ 670, 50 });

    /**** Settings Button ****/ 
    settings.setButtonColor(sf::Color::Transparent);
    settings.setText("");
    settings.setSize({ 100, 100 });
    settings.setPosition({ 30, 50 });

    /**** Textbox ****/
	textbox.setFont(font);
	textbox.setPosition({ 220, 400 });
	textbox.setLimit(true, 20);
}

/**********************************************************
*  Draw the page to the window.                           *
***********************************************************/
void ItemPage::drawPage(void)
{
    b.setPosition({ 200, 300 });

    /**** Draw ****/
    window->draw(sprite);
    window->draw(titleText);
    textbox.drawTo(*window);
    b.drawTo(*window);
    settings.drawTo(*window);
} 

/**********************************************************
*  Perform the event operations.                          *
***********************************************************/
void ItemPage::eventOperation(const sf::Event & event)
{
    // Press Esc to exit the application
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Escape))
	{
		(*window).close();              // close window
	}

    // change color of the buttons when mouse hovers over it
    if (event.type == sf::Event::MouseMoved)
    {
        if (b.mouseHover(*window))
        {
            b.setButtonColor(sf::Color(155, 155, 206, 255));    //changes color
        }
        else 
        {
            b.setButtonColor(sf::Color(140, 140, 140, 250));      // keep the color the same
        }
    }

    // If a button was pressed, perform the operation tied to the button
    if (event.type == sf::Event::MouseButtonPressed)
    {
        if (settings.mouseHover(*window))           // if the settings button is pressed, change to settings page
        {
            changePage = true;
            newPage = Page::CurrentPage::SettingsPage;
        }
    }

    //Homepage Button event operation
    if (event.type == sf::Event::MouseButtonPressed)
    {
        if (home.mouseHover(*window))           // if the home button is pressed, change to home page
        {
            changePage = true;
            newPage = Page::CurrentPage::HomePage;
        }
    }

    // for typing into the textbox
    if (event.type == sf::Event::TextEntered)
    {
		textbox.type(event);
    }

    // for typing into the textbox
    if (event.type == sf::Event::TextEntered)
    {
		textbox.type(event);
    }

    // Select the textbox
    if (event.type == sf::Event::MouseButtonReleased)
    {
        if (event.mouseButton.button == sf::Mouse::Left)
        {
            if (textbox.mouseHover(*window))
            {
                textbox.setSelected(true);
                textbox.setOutlineColor(sf::Color::Black);
            }
            else
            {
                textbox.setSelected(false);
                textbox.setOutlineColor(sf::Color(192, 192, 192, 250));
            }
        }
    }
} 